
  # SERMIL MAPS App Design

  This is a code bundle for SERMIL MAPS App Design. The original project is available at https://www.figma.com/design/t8SjsYcVczAZdrzW0Aa7Wz/SERMIL-MAPS-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  